package com.example.todoliste

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.*

// activity for changing Settings (main background color and language)
class SettingsActivity : AppCompatActivity() {

    private lateinit var spinnerColor: Spinner      // color selector
    private lateinit var spinnerLanguage: Spinner   // language selector
    private lateinit var buttonSettings: Button
    private var spinnerColorIndex: Int = -1
    private var spinnerLanguageIndex: Int = -1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)

        // init widgets
        spinnerColor = findViewById(R.id.spinnerSettingsBackgroundColor)
        spinnerLanguage = findViewById(R.id.spinnerSettingsLanguage)
        buttonSettings = findViewById(R.id.buttonSettings)

        // selection of available languages
        // connect to adapter
        val languages = arrayOf("English", "Deutsch", "Español", "Français", "Italiano", "Nederlands", "Português", "Polski", "Русский", "Türkçe")
        val arrayAdpLang = ArrayAdapter(this@SettingsActivity, R.layout.spinner_item, languages)
        spinnerLanguage.adapter = arrayAdpLang

        // set selection of colors
        // connect to adapter
        val colors = CustomColors.default
        val arrayAdpCol = ArrayAdapter(this@SettingsActivity, R.layout.spinner_item, colors)
        spinnerColor.adapter = arrayAdpCol

        // set index of selected language
        spinnerLanguage.onItemSelectedListener = object : AdapterView.OnItemSelectedListener{
            override fun onItemSelected(p0: AdapterView<*>?, p1: View?, p2: Int, p3: Long) {
                spinnerLanguageIndex = p2
            }

            override fun onNothingSelected(p0: AdapterView<*>?) {
                spinnerLanguageIndex = -1
            }
        }

        // set index of selected color
        spinnerColor.onItemSelectedListener = object : AdapterView.OnItemSelectedListener{
            override fun onItemSelected(p0: AdapterView<*>?, p1: View?, p2: Int, p3: Long) {
                spinnerColorIndex = p2
            }

            override fun onNothingSelected(p0: AdapterView<*>?) {
                spinnerColorIndex = -1
            }
        }

        // set selection to Settings.background
        var existsColor = false
        for(index in colors.indices){
            if(CustomColors.getColorId(colors[index], applicationContext) == CustomColors.getColorId(Settings.background, applicationContext)){
                existsColor = true
                spinnerColor.setSelection(index)
                break
            }
        }
        if(!existsColor){ // default color if color is unknown
            spinnerColor.setSelection(0)
        }

        // set selection to Settings.language
        var existsLang = false
        for(index in languages.indices){
            if(Settings.shortenLanguage(languages[index]) == Settings.shortenLanguage(Settings.language)){
                spinnerLanguage.setSelection(index)
                existsLang = true
                break
            }
        }
        if(!existsLang){ // default language if language is unknown
            spinnerLanguage.setSelection(0)
        }

        // save settings
        buttonSettings.setOnClickListener{
            saveSettings()
        }

    }

    // save settings
    private fun saveSettings(){
        if(spinnerLanguageIndex != -1 && spinnerColorIndex != -1 ){
            val intent = Intent("save_settings")
            intent.putExtra("language", spinnerLanguage.getItemAtPosition(spinnerLanguageIndex).toString())
            intent.putExtra("background", spinnerColor.getItemAtPosition(spinnerColorIndex).toString())
            setResult(CustomResultCodes.SAVE_SETTINGS, intent)
            finish()
        }
        else{ // Error during selection
            Toast.makeText(applicationContext,resources.getString(R.string.error_selection_settings),Toast.LENGTH_SHORT).show()
        }
    }

}