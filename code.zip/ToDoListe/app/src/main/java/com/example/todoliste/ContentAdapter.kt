package com.example.todoliste
import android.annotation.SuppressLint
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import java.util.*
import kotlin.math.abs

// Adapter for a item list (list of Content)
// Adapter is used to manage ViewHolder actions in RecyclerView
class ContentAdapter(private var dataList: MutableList<Content>) : RecyclerView.Adapter<ContentAdapter.ViewHolder>() {

    // for left swipe
    private var onItemDeleteListener: OnItemDeleteListener? = null

    // for right swipe
    private var onItemEditListener: OnItemEditListener? = null

    // create and set layout of ViewHolder
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_layout, parent, false)
        return ViewHolder(view)
    }

    // bind ViewHolder to out data (Content)
    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val data = dataList[position]
        holder.bindData(data, position)
    }

    // length of Adapter / RecyclerView = length of List (of Content, ContentList.list)
    override fun getItemCount(): Int {
        return dataList.size
    }

    // connect listener to edit listener (used in ListActivity)
    fun setOnItemEditListener(listener: OnItemEditListener) {
        this.onItemEditListener = listener
    }

    // connect listener to delete listener (used in ListActivity)
    fun setOnItemDeleteListener(listener: OnItemDeleteListener) {
        this.onItemDeleteListener = listener
    }

    // manages ViewHolder (item | Content)
    inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val itemText: TextView = itemView.findViewById(R.id.item_text)
        private val itemPriority: TextView = itemView.findViewById(R.id.item_priority)
        private val itemLayout: LinearLayout = itemView.findViewById(R.id.swipe_layout)
        private val shape = GradientDrawable() // not as drawable -> more control about border and background color

        init{
            // default look
            val colorResId = CustomColors.getColorId(CustomColors.default[0], itemView.context)
            shape.cornerRadius = Settings.cornerRadius
            if (colorResId != 0) {
                shape.setColor(ContextCompat.getColor(itemView.context, colorResId))
            }
            shape.setStroke(Settings.borderWidth,  Settings.borderColor )
            itemLayout.background = shape
        }

        // bind ViewHolder to data (Content)
        fun bindData(data: Content, position: Int) {

            // set text
            itemText.text = data.text

            val itemPriorityText: String = itemView.context.getString(R.string.priority_short) + data.priority.toString()
            itemPriority.text = itemPriorityText

            // set look
            val colorResId = CustomColors.getColorId(data.color, itemView.context)
            if (colorResId != 0) {
                shape.setColor(ContextCompat.getColor(itemView.context, colorResId))
            }
            else{
                println("Unknown Color ID")
            }
            itemLayout.background = shape
            shape.setStroke(Settings.borderWidth, Settings.borderColor)

            // manages swiping
            itemView.setOnTouchListener(object : View.OnTouchListener {
                private var startX = 0f
                private var startY = 0f

                // tracks distance and decides if left or right
                @SuppressLint("ClickableViewAccessibility")
                override fun onTouch(view: View, event: MotionEvent): Boolean {
                    when (event.action) {
                        MotionEvent.ACTION_DOWN -> { // Start Swipe
                            startX = event.x
                            startY = event.y
                        }
                        MotionEvent.ACTION_UP -> { // End Swipe
                            val deltaX = event.x - startX
                            val deltaY = event.y - startY
                            if (deltaX > SwipeSettings.THRESHOLD && abs(deltaY) < SwipeSettings.MAX_OFF_PATH) { // right swipe
                                onItemEditListener?.onItemEdit(position) // Edit
                            }
                            else if (deltaX < - SwipeSettings.THRESHOLD && abs(deltaY) < SwipeSettings.MAX_OFF_PATH) { // left swipe
                                onItemDeleteListener?.onItemDeleted(position) // delete
                            }
                        }
                    }
                    return true
                }
            })
        }
    }

    // updates whole adapter with new list data
    @SuppressLint("NotifyDataSetChanged")
    fun updateData(dataList: MutableList<Content>) {
        this.dataList = dataList
        notifyDataSetChanged()
    }

    // run ListActivity.onItemEdit()
    // open EditItemActivity
    interface OnItemEditListener {
        fun onItemEdit(position: Int)
    }

    // run ListActivity.onItemDeleted()
    // deletes item
    interface OnItemDeleteListener {
        fun onItemDeleted(position: Int)
    }
}