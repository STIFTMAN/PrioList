package com.example.todoliste

import android.graphics.Color
import java.util.*

// global settings
object Settings{
    // default color for main background
    // changed to saved background color
    var background: String = CustomColors.default[0]

    // default language
    // changed to saved language
    var language: String = Locale.getDefault().language

    // Settings for look of ViewHolder
    const val cornerRadius = 30f  // corner roundness (Float) for ViewHolder
    const val borderWidth = 2
    const val borderColor = Color.WHITE

    // converts long languages to its shorten form
    // Unit Test possible
    fun shortenLanguage(lang: String): String{
        when (lang) {
            "Deutsch" -> {
                return "de"
            }
            "English" -> {
                return "en"
            }
            "Français" -> {
                return "fr"
            }
            "Español" -> {
                return "es"
            }
            "Italiano" -> {
                return "it"
            }
            "Nederlands" -> {
                return "nl"
            }
            "Português" -> {
                return "pt"
            }
            "Polski" -> {
                return "pl"
            }
            "Русский" -> {
                return "ru"
            }
            "Türkçe" -> {
                return "tr"
            }
        }
        return "en"
    }
}
