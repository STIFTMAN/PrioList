package com.example.todoliste


// swipe settings for ViewHolder
object SwipeSettings {
    const val THRESHOLD = 150   // +- x
    const val MAX_OFF_PATH = 20 // +- y
    const val LONG_CLICK_DURATION = 1000L // in ms
}