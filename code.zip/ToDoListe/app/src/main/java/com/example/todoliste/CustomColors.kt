package com.example.todoliste

import android.annotation.SuppressLint
import android.content.Context
import java.util.*

// manages colors in different languages
object CustomColors {
    private val de = arrayOf("Schwarz", "Grau", "Blau", "Türkis",    "Lila",   "Orange", "Grün",  "Gelb",   "Rot")
    private val en = arrayOf("Black",   "Grey", "Blue", "Turquoise", "Purple", "Orange", "Green", "Yellow", "Red")
    private val es = arrayOf("Negro", "Gris", "Azul", "Turquesa", "Morado", "Naranja", "Verde", "Amarillo", "Rojo")
    private val fr = arrayOf("Noir", "Gris", "Bleu", "Turquoise", "Violet", "Orange", "Vert", "Jaune", "Rouge")
    private val it = arrayOf("Nero", "Grigio", "Blu", "Turchese", "Viola", "Arancione", "Verde", "Giallo", "Rosso")
    private val nl = arrayOf("Zwart", "Grijs", "Blauw", "Turkoois", "Paars", "Oranje", "Groen", "Geel", "Rood")
    private val pt = arrayOf("Preto", "Cinza", "Azul", "Turquesa", "Roxo", "Laranja", "Verde", "Amarelo", "Vermelho")
    private val pl = arrayOf("Czarny", "Szary", "Niebieski", "Turkusowy", "Fioletowy", "Pomarańczowy", "Zielony", "Żółty", "Czerwony")
    private val ru = arrayOf("Черный", "Серый", "Синий", "Бирюзовый", "Фиолетовый", "Оранжевый", "Зеленый", "Желтый", "Красный")
    private val tr = arrayOf("Siyah", "Gri", "Mavi", "Turkuaz", "Mor", "Turuncu", "Yeşil", "Sarı", "Kırmızı")
    var default = en

    // set default to variable of short language code (de, en, ...) by passing equal string
    @Suppress("UNCHECKED_CAST")
    fun setLanguage(language:String){
        val field = this::class.java.getDeclaredField(language)
        field.isAccessible = true
        default = field.get(this) as Array<String>
    }

    // uses default color ids in "./values" (equal to english names)
    // returns color id
    // instrumented test tested
    @SuppressLint("DiscouragedApi")
    fun getColorId(color: String, context: Context): Int {
        var index: Int = -1
        if (de.contains(color)){
            index = de.indexOf(color)
        }
        else if(en.contains(color)){
            index = en.indexOf(color)
        }
        else if(es.contains(color)){
            index = es.indexOf(color)
        }
        else if(fr.contains(color)){
            index = fr.indexOf(color)
        }
        else if(it.contains(color)){
            index = it.indexOf(color)
        }
        else if(nl.contains(color)){
            index = nl.indexOf(color)
        }
        else if(pt.contains(color)){
            index = pt.indexOf(color)
        }
        else if(pl.contains(color)){
            index = pl.indexOf(color)
        }
        else if(ru.contains(color)){
            index = ru.indexOf(color)
        }
        else if(tr.contains(color)){
            index = tr.indexOf(color)
        }
        if(index >= 0) {
            return context.resources.getIdentifier(en[index].lowercase(Locale.ROOT), "color", context.packageName)
        }
        return 0
    }

}