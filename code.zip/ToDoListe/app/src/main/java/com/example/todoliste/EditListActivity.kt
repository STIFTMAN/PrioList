package com.example.todoliste

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.*

// activity for editing a list
class EditListActivity : AppCompatActivity() {

    private lateinit var addButton: Button
    private lateinit var addEditText: EditText
    private lateinit var addEditSpinnerColor: Spinner // color selector (spinner)
    private lateinit var addEditSpinnerBgColor: Spinner // background color selector (spinner)
    private lateinit var addEditDescription: EditText
    private var spinnerIndexColor = 0
    private var spinnerIndexBgColor = 0
    private var mode: Int = 0 // mode 0 = new list | mode 1 = edit old list
    private var oldname: String = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_edit_list)

        addButton = findViewById(R.id.editButton)
        addEditText = findViewById(R.id.editText)
        addEditSpinnerColor = findViewById(R.id.editSpinnerColor)
        addEditSpinnerBgColor = findViewById(R.id.editSpinnerBgColor)
        addEditDescription = findViewById(R.id.editDescriptionList)

        // get data
        val data = intent.getParcelableExtra("data", ContentList::class.java)
        mode = intent.getIntExtra("mode", 0)
        oldname = data?.text.toString()

        // set selection of colors
        val colors = CustomColors.default // depends on language setting

        // similar to other adapter but in small
        val arrayAdp = ArrayAdapter(this@EditListActivity, R.layout.spinner_item, colors)

        addEditSpinnerColor.adapter = arrayAdp
        addEditSpinnerBgColor.adapter = arrayAdp

        // set index of selected color
        addEditSpinnerColor.onItemSelectedListener = object : AdapterView.OnItemSelectedListener{
            override fun onItemSelected(p0: AdapterView<*>?, p1: View?, p2: Int, p3: Long) {
                spinnerIndexColor = p2
            }

            override fun onNothingSelected(p0: AdapterView<*>?) {
                spinnerIndexColor = -1
            }
        }

        // set index of selected background color
        addEditSpinnerBgColor.onItemSelectedListener = object : AdapterView.OnItemSelectedListener{
            override fun onItemSelected(p0: AdapterView<*>?, p1: View?, p2: Int, p3: Long) {
                spinnerIndexBgColor = p2
            }

            override fun onNothingSelected(p0: AdapterView<*>?) {
                spinnerIndexBgColor = -1
            }
        }

        // edit list
        if (data != null){
            addEditText.setText(data.text)
            addEditDescription.setText(data.description)
            var exists = false
            for(index in colors.indices){
                if(CustomColors.getColorId(colors[index], applicationContext) == CustomColors.getColorId(data.color, applicationContext)){
                    exists = true
                    addEditSpinnerColor.setSelection(index) // select color with index
                    break
                }
            }
            if(!exists){
                addEditSpinnerColor.setSelection(0) // default
            }

            var existsBg = false
            for(index in colors.indices){
                if(CustomColors.getColorId(colors[index], applicationContext) == CustomColors.getColorId(data.bgcolor, applicationContext)){
                    existsBg = true
                    addEditSpinnerBgColor.setSelection(index) // select background color with index
                    break
                }
            }
            if(!existsBg){
                addEditSpinnerBgColor.setSelection(0)   // default
            }
        }
        else {  // new list
            addEditSpinnerColor.setSelection(0) // default color
            addEditSpinnerBgColor.setSelection(0)
        }

        // save list
        addButton.setOnClickListener {
            val newData: ContentList? = prepareData()
            if(newData != null){
                val intent = Intent("save_list")
                intent.putExtra("data", newData)
                intent.putExtra("old_name", oldname)
                intent.putExtra("mode", mode)
                setResult(CustomResultCodes.EDIT_LIST, intent)
                finish()
            }
        }
        if(mode == 0){
            addButton.setText(R.string.add_list_button)
        }
        else{
            addButton.setText(R.string.edit_list_button)
        }
    }

    // prepare final data for return
    private fun prepareData(): ContentList? {

        if (spinnerIndexColor  == -1 || spinnerIndexBgColor == -1){
            Toast.makeText(applicationContext,resources.getString(R.string.error_color_picker), Toast.LENGTH_SHORT).show()
            return null
        }

        val text = addEditText.text.toString()
        val bgcolor = addEditSpinnerBgColor.getItemAtPosition(spinnerIndexBgColor).toString()
        val color = addEditSpinnerColor.getItemAtPosition(spinnerIndexColor).toString()
        val description = addEditDescription.text.toString()

        if (text.isEmpty()){
            Toast.makeText(applicationContext,resources.getString(R.string.error_short_name), Toast.LENGTH_SHORT).show()
            return null
        }
        if(description.length >= 60){
            Toast.makeText(applicationContext,resources.getString(R.string.error_long_description), Toast.LENGTH_SHORT).show()
            return null
        }
        var counter = 0
        for(i in description.indices){
            if(description[i] == '\n') {
                counter++
            }
        }
        if(counter >= 2) {
            Toast.makeText(applicationContext,resources.getString(R.string.error_too_many_line_breaks), Toast.LENGTH_SHORT).show()
            return null
        }
        return ContentList(text =text, list = mutableListOf(), description = description, bgcolor =bgcolor, color = color)
    }

}