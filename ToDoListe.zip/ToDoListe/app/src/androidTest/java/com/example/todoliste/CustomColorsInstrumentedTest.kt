package com.example.todoliste

import androidx.test.core.app.ActivityScenario
import androidx.test.ext.junit.runners.AndroidJUnit4
import org.junit.Assert
import org.junit.Test
import org.junit.runner.RunWith


// test of functionality of CustomColors using Instrumented Test (no Unit, because we need instance of activity)
@RunWith(AndroidJUnit4::class)
class CustomColorsInstrumentedTest {

    @Test
    fun testGetColorId() {
        val scenario = ActivityScenario.launch(MainActivity::class.java)

        scenario.onActivity { activity ->
            val context = activity.applicationContext
            val result = CustomColors.getColorId("not a color", context)

            Assert.assertEquals(0, result)
        }
    }

}
