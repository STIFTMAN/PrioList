package com.example.todoliste

import androidx.test.core.app.ActivityScenario
import androidx.test.ext.junit.runners.AndroidJUnit4
import org.junit.Assert
import org.junit.Test
import org.junit.runner.RunWith

// test of functionality of EditItemActivity using Instrumented Test (no Unit, because we need instance of activity)
@RunWith(AndroidJUnit4::class)
class EditItemInstrumentedTest {

    @Test
    fun testIsNumber(){
        val scenario = ActivityScenario.launch(EditItemActivity::class.java)

        scenario.onActivity { activity ->
            val result = activity.isNumber("34")

            Assert.assertEquals(true, result)
        }
    }
}