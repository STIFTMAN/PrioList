package com.example.todoliste

import org.junit.Assert
import org.junit.Test

class SettingsUnitTest {

    @Test
    fun testShortLanguage(){
        val result = Settings.shortenLanguage("Français")

        Assert.assertEquals("fr", result)
    }
}