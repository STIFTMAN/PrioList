package com.example.todoliste

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

// activity for editing
class EditItemActivity : AppCompatActivity() {

    private lateinit var addButton: Button
    private lateinit var addEditText: EditText
    private lateinit var addEditSpinner: Spinner // color selector (spinner)
    private lateinit var addEditPriority: EditText
    private var spinnerIndex = 0
    private var mode: Int = 0 // mode 0 = try new item | mode 1 = edit old item
    private var color: String = CustomColors.default[0] // default color if new item
    private var oldname: String = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_edit_item)

        addButton = findViewById(R.id.editButton)
        addEditText = findViewById(R.id.editText)
        addEditSpinner = findViewById(R.id.editSpinnerColor)
        addEditPriority = findViewById(R.id.editPriority)

        // get data
        val data = intent.getParcelableExtra("data", Content::class.java)
        mode = intent.getIntExtra("mode", 0)
        color = intent.getStringExtra("color").toString() // default color
        oldname = data?.text.toString() // old item name

        // set selection of colors
        val colors = CustomColors.default

        // similar to other adapter but in small
        val arrayAdp = ArrayAdapter(this@EditItemActivity, R.layout.spinner_item, colors)

        addEditSpinner.adapter = arrayAdp

        // set index of selected color
        addEditSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener{
            override fun onItemSelected(p0: AdapterView<*>?, p1: View?, p2: Int, p3: Long) {
                spinnerIndex = p2
            }

            override fun onNothingSelected(p0: AdapterView<*>?) { // on error
                spinnerIndex = -1
            }
        }

        // edit item
        if (data != null){
            addEditText.setText(data.text)
            addEditPriority.setText(data.priority.toString())
            var exists = false
            for(index in colors.indices){
                if(CustomColors.getColorId(colors[index], applicationContext) == CustomColors.getColorId(data.color, applicationContext)){ // old color
                    exists = true
                    addEditSpinner.setSelection(index) // select color with index
                    break
                }
            }
            if(!exists){
                addEditSpinner.setSelection(0) // default if default color is unknown
                for(index in colors.indices){
                    if(CustomColors.getColorId(colors[index], applicationContext) == CustomColors.getColorId(color, applicationContext)){ // preset color
                        addEditSpinner.setSelection(index)
                        break
                    }
                }
            }
        }
        else { // new item
            addEditSpinner.setSelection(0) // default color
            for(index in colors.indices){
                if(colors[index] == color){ // preset color
                    addEditSpinner.setSelection(index)
                    break
                }
            }
        }

        // save item
        addButton.setOnClickListener {
            val newData: Content? = prepareData()
            if(newData != null){
                val intent = Intent("save_item")
                intent.putExtra("data", newData)
                intent.putExtra("old_name", oldname)
                intent.putExtra("mode", mode)
                setResult(CustomResultCodes.EDIT_ITEM, intent)
                finish()
            }
        }
        if(mode == 0){
            addButton.setText(R.string.add_item_button)
        }
        else{
            addButton.setText(R.string.edit_item_button)
        }
    }

    // check if string is number
    // instrumented test tested
    fun isNumber(s: String?): Boolean {
        return if (s.isNullOrEmpty()) false else s.all { Character.isDigit(it) }
    }

    // prepare final data for return
    private fun prepareData(): Content? {

        if (spinnerIndex  == -1){
            Toast.makeText(applicationContext,resources.getString(R.string.error_color_picker), Toast.LENGTH_SHORT).show()
            return null
        }

        val text = addEditText.text.toString()
        val color = addEditSpinner.getItemAtPosition(spinnerIndex).toString()
        var priority = 0
        if (isNumber(addEditPriority.text.toString())){
            priority = addEditPriority.text.toString().toInt()
        }
        else{
            addEditPriority.setText("0") // default priority
            Toast.makeText(applicationContext,resources.getString(R.string.error_input_priority), Toast.LENGTH_SHORT).show()
        }
        if (text.isEmpty()){
            Toast.makeText(applicationContext,resources.getString(R.string.error_short_name), Toast.LENGTH_SHORT).show()
            return null
        }
        return Content(text=text, priority = priority, color = color)
    }
}