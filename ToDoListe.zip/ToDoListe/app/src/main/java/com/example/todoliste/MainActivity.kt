package com.example.todoliste

import android.annotation.SuppressLint
import androidx.activity.result.ActivityResult
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import org.json.JSONArray
import org.json.JSONException
import org.json.JSONObject
import java.io.*
import android.app.AlertDialog
import android.widget.ImageButton
import androidx.core.content.ContextCompat
import java.util.*

// Main Screen / root
// click / delete / edit / long press --- listeners (interface between adapter and Activity)
class MainActivity : AppCompatActivity(), ContentAdapterList.OnItemClickListener, ContentAdapterList.OnItemDeleteListener, ContentAdapterList.OnItemEditListener, ContentAdapterList.OnItemLongClickListener {

    // 3 buttons on main screen
    private lateinit var addButtonList: ImageButton
    private lateinit var addButtonTutorial: ImageButton
    private lateinit var addButtonSettings: ImageButton

    // editable scrollable container to view a list
    private lateinit var recyclerViewList: RecyclerView

    // main data of whole app
    // dataListList because it is a list of list
    private var dataListList = mutableListOf<ContentList>()

    // interface to control every item in a RecyclerView
    private val adapterList = ContentAdapterList(dataListList)

    // onActivityResult is deprecated -- new way of handling result value
    private var resultLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result: ActivityResult ->
        val data: Intent? = result.data

        if (result.resultCode == CustomResultCodes.LIST) { // usage of own result codes (CustomResultCodes)
            val receivedData = data?.getParcelableExtra("data", ContentList::class.java) // Get object
            saveData(receivedData)
        }
        else if (result.resultCode == CustomResultCodes.EDIT_LIST) { // back from editing a list
            val receivedData = data?.getParcelableExtra("data", ContentList::class.java)
            val oldname = data?.getStringExtra("old_name")
            var exists = -1
            for (i in dataListList.indices){
                if(dataListList[i].text == oldname){ // get old index
                    exists = i
                    break
                }
            }
            if(exists == -1) { // new list
                dataListList.add(
                    ContentList(
                        text = receivedData?.text.toString(),
                        list = mutableListOf(),
                        description = receivedData?.description.toString(),
                        bgcolor = receivedData?.bgcolor!!,
                        color = receivedData.color
                    )
                )
                val position = dataListList.size - 1
                adapterList.notifyItemInserted(position)
                saveData(null)
                Toast.makeText(applicationContext,resources.getString(R.string.list_added),Toast.LENGTH_SHORT).show()
            }
            else{ // list name already exists
                val mode = data?.getIntExtra("mode", 0) // mode 0 = try  new list | mode 1 = edit old list
                if (mode == 0){ // tried to name a list to another lists name
                    Toast.makeText(applicationContext,resources.getString(R.string.error_list_exists),Toast.LENGTH_SHORT).show()
                    backToEdit(receivedData, 0)
                }
                else{ // change data
                    dataListList[exists].text = receivedData?.text.toString()
                    dataListList[exists].description = receivedData?.description.toString()
                    dataListList[exists].bgcolor = receivedData?.bgcolor!!
                    dataListList[exists].color = receivedData.color
                    Toast.makeText(applicationContext,resources.getString(R.string.list_edited),Toast.LENGTH_SHORT).show()
                    adapterList.notifyItemChanged(exists)
                }
            }
        }
        else if(result.resultCode == CustomResultCodes.SAVE_SETTINGS) { // Back from Settings
            val language = data?.getStringExtra("language")
            val background = data?.getStringExtra("background")
            if (language != null && background != null) {
                Settings.background = background
                Settings.language = language
                saveSettings()

                // Change main background
                val colorResId = CustomColors.getColorId(Settings.background, recyclerViewList.context)
                if (colorResId != 0) {
                    recyclerViewList.setBackgroundColor(ContextCompat.getColor(this, colorResId))
                }
                else{
                    Toast.makeText(applicationContext,resources.getString(R.string.error_unknown_color_id),Toast.LENGTH_SHORT).show()
                }

                // change language
                setAppLanguage(Settings.shortenLanguage(Settings.language))
                CustomColors.setLanguage(Settings.shortenLanguage(Settings.language))
                recreate() // rebuild activity to load new language
                Toast.makeText(applicationContext,resources.getString(R.string.settings_saved),Toast.LENGTH_SHORT).show()

            }
            else{
                Toast.makeText(applicationContext,resources.getString(R.string.error_save_settings),Toast.LENGTH_SHORT).show()
            }
        }
    }

    // similar to resultLauncher / onActivityResult, receive data without changing activity
    // get data from ListActivity, if item is added (prohibits usage of global variable)
    private val broadcastReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent) {
            val receivedData = intent.getParcelableExtra("data", ContentList::class.java)
            saveData(receivedData)
        }
    }

    // like main()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // read list data
        if (!readFile()){
            Toast.makeText(applicationContext,resources.getString(R.string.error_loading_data),Toast.LENGTH_SHORT).show()
        }

        // read Settings
        if(!readSettings()){
            Toast.makeText(applicationContext,resources.getString(R.string.error_loading_settings),Toast.LENGTH_SHORT).show()
            saveSettings()
        }

        // changes language to specified language (Locale.getDefault().language -> Settings.language)
        if(Locale.getDefault().language != Settings.language){
            setAppLanguage(Settings.shortenLanguage(Settings.language))
        }

        // changes language color set to specified language
        CustomColors.setLanguage(Settings.shortenLanguage(Settings.language))
        println("Init Language: " + resources.configuration.locales[0].language)

        recyclerViewList = findViewById(R.id.recyclerViewList)
        recyclerViewList.layoutManager = LinearLayoutManager(this)

        // set background color
        val colorResId = CustomColors.getColorId(Settings.background, recyclerViewList.context)
        if (colorResId != 0) {
            recyclerViewList.setBackgroundColor(ContextCompat.getColor(this, colorResId))
        }
        else{
            Toast.makeText(applicationContext,resources.getString(R.string.error_unknown_color_id),Toast.LENGTH_SHORT).show()
        }

        // set listeners
        adapterList.setOnItemDeleteListener(this)
        adapterList.setOnItemEditListener(this)
        adapterList.setOnItemClickListener(this)
        adapterList.setOnItemLongClickListener(this)

        // connects adapter and RecyclerView
        recyclerViewList.adapter = adapterList

        // Set Buttons
        addButtonSettings = findViewById(R.id.settings_button)
        addButtonSettings.setOnClickListener { // to settings
            val intent = Intent(this, SettingsActivity::class.java)
            resultLauncher.launch(intent)
        }

        addButtonTutorial = findViewById(R.id.tutorial_button)
        addButtonTutorial.setOnClickListener { // to tutorial
            val intent = Intent(this, TutorialActivity::class.java)
            resultLauncher.launch(intent)
        }

        addButtonList = findViewById(R.id.add_content_button_list)
        addButtonList.setOnClickListener { // add new list (to editing activity with no data)
            backToEdit(null, 0)
        }

        // set broadcaster
        val intentFilter = IntentFilter("save_item")
        registerReceiver(broadcastReceiver, intentFilter)
    }

    // changes language package
    @Suppress("DEPRECATION")
    private fun setAppLanguage(languageCode: String) {

        val locale = Locale(languageCode)
        Locale.setDefault(locale)

        val config = resources.configuration
        config.setLocale(locale)
        resources.updateConfiguration(config, resources.displayMetrics) // Deprecated, but no replacement available in API

    }

    // switch to EditListActivity with some data
    private fun backToEdit(data: ContentList?, mode: Int){ // mode 0 = new | mode 1 = old
        val intent = Intent(this, EditListActivity::class.java)
        intent.putExtra("data",  data)
        intent.putExtra("mode", mode)
        resultLauncher.launch(intent)
    }

    // saves settings from global Settings in local file called settings.json in json-format
    private fun saveSettings(){
        val fileName = "settings.json"
        val jsonObject = JSONObject()
        jsonObject.put("language", Settings.language)
        jsonObject.put("background", Settings.background)

        val file = File(filesDir,fileName)
        file.writeText(jsonObject.toString())

        // checks, if working file or directory exists after writing
        // if not -> Error
        val directory = File(filesDir,".")
        if (!(directory.exists() && directory.isDirectory)) {
            Toast.makeText(applicationContext,resources.getString(R.string.error_no_directory),Toast.LENGTH_SHORT).show()
        }
        if (!File(filesDir, fileName).exists()) {
            Toast.makeText(applicationContext,resources.getString(R.string.error_no_file),Toast.LENGTH_SHORT).show()
        }
    }

    // read settings from settings.json in global Settings
    // return false on error | true on success
    private fun readSettings(): Boolean{
        val fileName = "settings.json"
        if(!File(filesDir, fileName).exists()){
            return false
        }
        val file = File(filesDir, fileName)
        val fileContent = file.readText()
        return try{
            val jsonObject = JSONObject(fileContent)
            val language = jsonObject.getString("language")
            val background = jsonObject.getString("background")
            Settings.language = language
            Settings.background = background
            true
        } catch (e: JSONException) {
            e.printStackTrace()
            false
        }
    }

    // read data from data.json in local dataListList
    // return false on error | true on success
    private fun readFile(): Boolean{
        val fileName = "data.json"

        if(!File(filesDir, fileName).exists()){ // run on first start | no file
            saveData(null) // create file to prevent showing error messages because of no found file
            return false
        }
        val file = File(filesDir, fileName)
        val fileContent = file.readText()

        // converts json string to object lists of ContentList() and Content()
        try {
            val jsonArray = JSONArray(fileContent)

            for (i in 0 until jsonArray.length()){
                val jsonObject = jsonArray.getJSONObject(i)
                val textList = jsonObject.getString("text")
                val description = jsonObject.getString("description")
                val bgColorList = jsonObject.getString("bgcolor")
                val colorList = jsonObject.getString("color")

                // create a list
                val cont = ContentList(list = mutableListOf(), text = textList, description =description, bgcolor =bgColorList, color =colorList)

                // create items of a list
                val list = jsonObject.getJSONArray("list")
                for (index in 0 until list.length()){
                    val item = JSONObject(list.getString(index))
                    val text = item.getString("text")
                    val priority = item.getInt("priority")
                    val color = item.getString("color")
                    val content = Content(text = text, priority = priority, color = color)
                    cont.list.add(content) // add items to list
                }
                // add list to array (lists of lists)
                dataListList.add(cont)
            }
            return true
        } catch (e: JSONException) {
            e.printStackTrace()
            return false
        }
    }

    // called from interface -- event listener -- ContentAdapterList
    // start ListActivity with data
    override fun onItemClick(position: Int) {
        val intent = Intent(this, ListActivity::class.java)
        intent.putExtra("data",  dataListList[position])
        resultLauncher.launch(intent)

    }

    // called from interface -- event listener -- ContentAdapterList
    // show description of list
    override fun onItemLongClick(position: Int){
        Toast.makeText(applicationContext, dataListList[position].description ,Toast.LENGTH_LONG).show()
    }

    // called from interface -- event listener -- ContentAdapterList
    // edit existing list
    override fun onItemEdit(position: Int) {
        backToEdit(dataListList[position], 1)
    }

    // saves list data from local dataListList in local file called data.json in json-format
    fun saveData(data: ContentList?){

        if (data != null) { // happens if received data from broadcast
            for (i in dataListList.indices) { // updates items in list
                if (dataListList[i].text == data.text) {
                    dataListList[i].list = data.list
                    adapterList.updateView(i)
                }
            }
        }

        val fileName = "data.json"

        val jsonArray = JSONArray()

        // convert data to json object
        try {
            for (item: ContentList in dataListList) {
                val jsonObject = JSONObject()
                jsonObject.put("text", item.text)
                val jsonArrayList = JSONArray()
                for (list in item.list) {
                    val jsonObjectList = JSONObject()
                    jsonObjectList.put("text", list.text)
                    jsonObjectList.put("priority", list.priority)
                    jsonObjectList.put("color", list.color)
                    jsonArrayList.put(jsonObjectList)
                }
                jsonObject.put("list", jsonArrayList)
                jsonObject.put("description", item.description)
                jsonObject.put("bgcolor", item.bgcolor)
                jsonObject.put("color", item.color)
                jsonArray.put(jsonObject)
            }
        } catch (e: JSONException) {
            e.printStackTrace()
        }

        // write in file
        val file = File(filesDir,fileName)
        file.writeText(jsonArray.toString())

        // checks, if working file or directory exists after writing
        // if not -> Error
        val directory = File(filesDir,".")
        if (!(directory.exists() && directory.isDirectory)) {
            Toast.makeText(applicationContext,resources.getString(R.string.error_no_directory),Toast.LENGTH_SHORT).show()
        }
        if (!File(filesDir, fileName).exists()) {
            Toast.makeText(applicationContext,resources.getString(R.string.error_no_file),Toast.LENGTH_SHORT).show()
        }
    }

    // safe unregister broadcast
    override fun onDestroy() {
        super.onDestroy()
        unregisterReceiver(broadcastReceiver)
    }

    // customizable dialog box using AlertDialog
    private fun showYesNoDialog(context: Context, title: String, message: String, yesListener: () -> Unit, noListener: () -> Unit) {
        val alertDialog = AlertDialog.Builder(context)
            .setTitle(title)
            .setMessage(message)
            .setPositiveButton(resources.getString(R.string.yes)) { _, _ -> // treated like a function
                yesListener.invoke()
            }
            .setNegativeButton(resources.getString(R.string.no)) { _, _ -> // treated like a function
                noListener.invoke()
            }
            .create()

        alertDialog.show()
    }

    // called from interface -- event listener -- ContentAdapterList
    // asking to delete list
    @SuppressLint("NotifyDataSetChanged")
    override fun onItemDeleted(position: Int) {
        showYesNoDialog(
            context = this,
            title = dataListList[position].text,
            message = resources.getString(R.string.list_size) + dataListList[position].list.size + resources.getString(R.string.entries) + resources.getString(R.string.question_really_delete),
            yesListener = {
                dataListList.removeAt(position)
                saveData(null)
                adapterList.notifyDataSetChanged()
                Toast.makeText(applicationContext,resources.getString(R.string.list_deleted),Toast.LENGTH_SHORT).show()
            },
            noListener = {
                Toast.makeText(applicationContext,resources.getString(R.string.cancel),Toast.LENGTH_SHORT).show()
            }
        )
    }

}
