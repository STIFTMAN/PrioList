package com.example.todoliste

import android.os.Parcel
import android.os.Parcelable

// list
// parcelable because easier to send objects via result using traditional parcelable implementation
data class ContentList(var list: MutableList<Content>, var text: String, var description: String, var bgcolor: String, var color: String) : Parcelable {
    constructor(parcel: Parcel) : this(parcel.createTypedArrayList(Content.CREATOR)?.toMutableList() ?: mutableListOf(),
        parcel.readString() ?: "",
        parcel.readString() ?: "",
        parcel.readString() ?: "",
        parcel.readString() ?: ""
    )

    override fun writeToParcel(parcel: Parcel, flags: Int) {
        parcel.writeTypedList(list)
        parcel.writeString(text)
        parcel.writeString(description)
        parcel.writeString(bgcolor)
        parcel.writeString(color)
    }

    override fun describeContents(): Int {
        return 0
    }

    companion object CREATOR : Parcelable.Creator<ContentList> {
        override fun createFromParcel(parcel: Parcel): ContentList {
            return ContentList(parcel)
        }

        override fun newArray(size: Int): Array<ContentList?> {
            return arrayOfNulls(size)
        }
    }
}