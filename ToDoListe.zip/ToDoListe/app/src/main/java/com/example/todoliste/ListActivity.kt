package com.example.todoliste

import android.annotation.SuppressLint
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ImageButton
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.util.*

// activity for listing a list ( show ContentList with items (ContentList.list))
//  delete / edit  --- listeners (interface between adapter and Activity)
class ListActivity : AppCompatActivity(), ContentAdapter.OnItemDeleteListener, ContentAdapter.OnItemEditListener {


    private lateinit var recyclerView: RecyclerView
    private lateinit var addButton: ImageButton
    private lateinit var listNameTextView: TextView

    private var listName = ""       // = ContentList.text
    private var description = ""    // = ContentList.description
    private var color = CustomColors.default[0].lowercase(Locale.ROOT) // background color item in list | = ContentList.bgcolor
    private var bgcolor = CustomColors.default[0].lowercase(Locale.ROOT) // background color of screen | = ContentList.color
    private var dataList = mutableListOf<Content>() // = ContentList.list

    // interface to control every item in a RecyclerView
    private val adapter = ContentAdapter(dataList)

    // onActivityResult is deprecated -- new way of handling result value
    private var resultLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        val data: Intent? = result.data
        val receivedData = data?.getParcelableExtra("data", Content::class.java)
        val mode = data?.getIntExtra("mode", 0)
        val oldName = data?.getStringExtra("old_name")

        // usage of own result codes (CustomResultCodes)
        if (result.resultCode == CustomResultCodes.EDIT_ITEM) { // back from editing a item
            var exists = -1
            for (i in dataList.indices){
                if(dataList[i].text == oldName){ // get old index
                    exists = i
                    break
                }
            }
            if(exists == -1) {   // new list
                dataList.add(
                    Content(
                        text = receivedData?.text.toString(),
                        color = receivedData?.color.toString(),
                        priority = receivedData?.priority.toString().toInt()
                    )
                )
                val position = dataList.size - 1
                adapter.notifyItemInserted(position)
                Toast.makeText(applicationContext,resources.getString(R.string.item_added),Toast.LENGTH_SHORT).show()
            }
            else{   // list name already exists
                if (mode == 0){ // new item
                    Toast.makeText(applicationContext,resources.getString(R.string.error_item_exists),Toast.LENGTH_SHORT).show()
                    backToEdit(receivedData, 0)
                }
                else{ // edit old item
                    dataList[exists].priority = receivedData?.priority.toString().toInt()
                    dataList[exists].color = receivedData?.color.toString()
                    dataList[exists].text = receivedData?.text.toString()
                    Toast.makeText(applicationContext,resources.getString(R.string.item_edited),Toast.LENGTH_SHORT).show()
                    adapter.notifyItemChanged(exists)
                }
            }
            updateDataList()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_list)

        recyclerView = findViewById(R.id.recyclerViewList)
        recyclerView.layoutManager = LinearLayoutManager(this)

        // set listeners
        adapter.setOnItemDeleteListener(this)
        adapter.setOnItemEditListener(this)

        recyclerView.adapter = adapter

        // get data
        val data = intent.getParcelableExtra("data", ContentList::class.java)

        listName = data?.text!!
        dataList =  data.list
        description = data.description
        bgcolor = data.bgcolor
        color = data.color

        // set background color
        val colorResId = CustomColors.getColorId(bgcolor, recyclerView.context)
        if (colorResId != 0) {
            recyclerView.setBackgroundColor(ContextCompat.getColor(this, colorResId))
        }
        else{
            Toast.makeText(applicationContext,resources.getString(R.string.error_unknown_color_id),Toast.LENGTH_SHORT).show()
        }

        listNameTextView = findViewById(R.id.listname)
        listNameTextView.text = listName
        addButton = findViewById(R.id.add_content_button_list)
        addButton.setOnClickListener {
            backToEdit(null, 0)
        }

        // insert old data to view
        adapter.updateData(dataList)
        updateDataList()

        // if back pressed -> return ContentList to MainActivity
        onBackPressedDispatcher.addCallback(this, object: OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                val resultIntent = Intent()
                resultIntent.putExtra("data", ContentList(list =dataList, text =listName, description = description, bgcolor =bgcolor, color = color))
                setResult(CustomResultCodes.LIST, resultIntent)
                finish()
            }
        })
    }

    // switch to EditItemActivity with Content data
    private fun backToEdit(data: Content?, mode: Int){
        val intent = Intent(this, EditItemActivity::class.java)
        intent.putExtra("data",  data)
        intent.putExtra("mode", mode)   // mode 0 = new item | mode 1 = edit old item
        intent.putExtra("color", color) // default color in selection
        resultLauncher.launch(intent)
    }

    @SuppressLint("NotifyDataSetChanged")
    private fun updateDataList(){
        dataList.sortByDescending { it.priority } // sort list descending by priority
        adapter.notifyDataSetChanged()

        // save data without leaving activity via broadcast
        val intent = Intent("save_item")
        intent.putExtra("data", ContentList(list =dataList, text =listName, description = description, bgcolor =bgcolor, color = color))
        sendBroadcast(intent)
    }

    // called from interface -- event listener -- ContentAdapter
    // start EditItemActivity with data
    override fun onItemEdit(position: Int) {
        backToEdit(dataList[position], 1)
    }

    // called from interface -- event listener -- ContentAdapter
    // removes item (Content) from list - without asking
    @SuppressLint("NotifyDataSetChanged")
    override fun onItemDeleted(position: Int) {
        dataList.removeAt(position)
        adapter.notifyDataSetChanged()
    }

}