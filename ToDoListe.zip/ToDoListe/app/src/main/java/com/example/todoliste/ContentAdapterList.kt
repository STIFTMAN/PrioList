package com.example.todoliste
import android.annotation.SuppressLint
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import android.view.MotionEvent
import android.widget.LinearLayout
import androidx.core.content.ContextCompat
import java.util.*
import kotlin.math.abs

// Adapter for a list list (list of ContentList)
// Adapter is used to manage ViewHolder actions in RecyclerView
class ContentAdapterList(private var dataList: List<ContentList>) : RecyclerView.Adapter<ContentAdapterList.ViewHolder>() {

    // for click
    private var onItemClickListener: OnItemClickListener? = null

    // for left swipe
    private var onItemDeleteListener: OnItemDeleteListener? = null

    // for right swipe
    private var onItemEditListener: OnItemEditListener? = null

    // for long press | click
    private var onItemLongClickListener: OnItemLongClickListener? = null

    // create and set layout of ViewHolder
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_layout_list, parent, false)
        return ViewHolder(view)
    }

    // bind ViewHolder to out data (ContentList)
    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val data = dataList[position]
        holder.bindData(data,position)
    }

    // length of Adapter / RecyclerView = length of List (of ContentList, mutableListOf<ContentList>)
    override fun getItemCount(): Int {
        return dataList.size
    }

    // updates adapter at position if item (in ContentList.list) changed via broadcast
    fun updateView(position: Int) {
        notifyItemChanged(position)
    }

    // connect listener to click listener (used in MainActivity)
    fun setOnItemClickListener(listener: OnItemClickListener) {
        this.onItemClickListener = listener
    }

    // connect listener to delete listener (used in MainActivity)
    fun setOnItemDeleteListener(listener: OnItemDeleteListener) {
        this.onItemDeleteListener = listener
    }

    // connect listener to edit listener (used in MainActivity)
    fun setOnItemEditListener(listener: OnItemEditListener) {
        this.onItemEditListener = listener
    }

    // connect listener to long click listener (used in MainActivity)
    fun setOnItemLongClickListener(listener: OnItemLongClickListener) {
        this.onItemLongClickListener = listener
    }

    // manages ViewHolder (list (as a item)| ContentList)
    inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val itemText: TextView = itemView.findViewById(R.id.item_text)
        private val itemCount: TextView = itemView.findViewById(R.id.item_count)
        private val itemLayout: LinearLayout = itemView.findViewById(R.id.item_layout)
        private val shape = GradientDrawable()  // not as drawable -> more control about border and background color

        init{
            // default look
            shape.cornerRadius = Settings.cornerRadius
            val colorResId = CustomColors.getColorId(CustomColors.default[0], itemView.context)
            if (colorResId != 0){
                shape.setColor(ContextCompat.getColor(itemView.context, colorResId))
            }
            else{
                println("Unknown Color Id")
            }
            shape.setStroke(Settings.borderWidth,  Settings.borderColor )
            itemLayout.background = shape

        }

        // bind ViewHolder to data (ContentList)
        fun bindData(data: ContentList, position: Int) {

            // set text
            itemText.text = data.text

            val itemCountText: String = itemView.context.getString(R.string.size_short) + data.list.size.toString() // size of list as text
            itemCount.text = itemCountText

            // set look
            val colorResId = CustomColors.getColorId(data.bgcolor, itemView.context)
            if (colorResId != 0) {
                shape.setColor(ContextCompat.getColor(itemView.context, colorResId))
            }
            else{
                println("Unknown Color ID")
            }
            shape.setStroke(Settings.borderWidth,  Settings.borderColor )
            itemLayout.background = shape

            // manages swiping
            itemView.setOnTouchListener(object : View.OnTouchListener {
                private var startX = 0f
                private var startY = 0f
                private var isLongClick = false

                // executed if user pressed ViewHolder long longer than SwipeSettings.LONG_CLICK_DURATION
                private val longClickRunnable = Runnable {
                    isLongClick = true
                    onItemLongClickListener?.onItemLongClick(position)
                }

                // tracks distance and decides if left or right
                @SuppressLint("ClickableViewAccessibility")
                override fun onTouch(view: View, event: MotionEvent): Boolean {
                    when (event.action) {
                        MotionEvent.ACTION_DOWN -> { // start swipe and press
                            startX = event.x
                            startY = event.y
                            isLongClick = false
                            view.postDelayed(longClickRunnable, SwipeSettings.LONG_CLICK_DURATION) // set duration for long click / press
                        }
                        MotionEvent.ACTION_MOVE -> { // disables longClickRunnable if swipe is out of ViewHolder
                            val deltaX = event.x - startX
                            val deltaY = event.y - startY
                            if (abs(deltaX) > SwipeSettings.THRESHOLD || abs(deltaY) > SwipeSettings.THRESHOLD) {
                                view.removeCallbacks(longClickRunnable)
                            }
                        }

                        MotionEvent.ACTION_UP -> { // End Swipe
                            view.removeCallbacks(longClickRunnable) // disables longClickRunnable
                            val deltaX = event.x - startX
                            val deltaY = event.y - startY
                            if (deltaX > SwipeSettings.THRESHOLD && abs(deltaY) < SwipeSettings.MAX_OFF_PATH) { // right swipe
                                onItemEditListener?.onItemEdit(position) // Edit
                            }
                            else if (deltaX < - SwipeSettings.THRESHOLD && abs(deltaY) < SwipeSettings.MAX_OFF_PATH) { // left swipe
                                onItemDeleteListener?.onItemDeleted(position) // Delete
                            }
                            else if (abs(deltaX) < SwipeSettings.MAX_OFF_PATH && abs(deltaY) < SwipeSettings.MAX_OFF_PATH){ // Click

                                if (!isLongClick) {
                                    onItemClickListener?.onItemClick(position) // normal click
                                }
                            }

                        }
                    }
                    return true
                }
            })
        }
    }

    // run MainActivity.onItemDeleted()
    // deletes List
    interface OnItemDeleteListener {
        fun onItemDeleted(position: Int)
    }

    // run MainActivity.onItemClick()
    // open ListActivity
    interface OnItemClickListener {
        fun onItemClick(position: Int)
    }

    // run MainActivity.onItemEdit()
    // open EditListActivity
    interface OnItemEditListener {
        fun onItemEdit(position: Int)
    }

    // run MainActivity.onItemLongClick()
    // show description of list
    interface OnItemLongClickListener {
        fun onItemLongClick(position: Int)
    }
}