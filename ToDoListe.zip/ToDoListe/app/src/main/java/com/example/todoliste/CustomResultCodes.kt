package com.example.todoliste

// custom result codes because default codes doesn't fit in meaning
object CustomResultCodes {
    const val LIST = 100
    const val EDIT_LIST = 200
    const val EDIT_ITEM = 300
    const val SAVE_SETTINGS = 400
}